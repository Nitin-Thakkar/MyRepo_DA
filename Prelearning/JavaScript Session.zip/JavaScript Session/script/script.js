 function greetPerson()
{
    var name =  document.getElementById("txtName").value;
    console.log(name+" is entered");
   
    alert("Welcome from External JavaScript => "+name);
    
}